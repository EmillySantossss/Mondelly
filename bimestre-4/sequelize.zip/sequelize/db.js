const {Sequelize} = require('sequelize');
const sequelize = new Sequelize(
    'sequelize',
    'root',
    'aluno.ifal', 
    {
        host: 'localhost',
        dialect: 'mysql'
    }
);
module.exports = sequelize;