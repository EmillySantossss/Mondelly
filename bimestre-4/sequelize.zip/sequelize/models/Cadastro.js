const { DataTypes } = require('sequelize');
const sequelize= require('../db');

const Cadastro = sequelize.define('Cadastro', {
  id_cadastro: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  senha: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  data_nascimento: {
    type: DataTypes.STRING(10),
  },
  cpf: {
    type: DataTypes.STRING(11),
    unique: true,
  },
  rg: {
    type: DataTypes.STRING(20),
  },
  sexo: {
    type: DataTypes.CHAR(1),
  },
  cep: {
    type: DataTypes.STRING(8),
  },
  endereco: {
    type: DataTypes.STRING,
  },
  bairro: {
    type: DataTypes.STRING(100),
  },
  cidade: {
    type: DataTypes.STRING(100),
  },
  telefone: {
    type: DataTypes.STRING(15),
  },
});

module.exports = Cadastro;
