const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Favorito = sequelize.define('Favorito', {
    id_favorito: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    id_cadastro: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    id_produto: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    data_adicionado: {
      type: DataTypes.STRING(10),
    },
  });
  
module.exports = Favorito;
