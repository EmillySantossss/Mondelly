const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Perfil = sequelize.define('Perfil', {
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  biografia: {
    type: DataTypes.TEXT,
  },
  id_imagem: {
    type: DataTypes.INTEGER,
  },
});

module.exports = Perfil;
