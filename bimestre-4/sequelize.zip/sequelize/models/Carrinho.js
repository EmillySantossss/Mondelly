const { DataTypes } = require('sequelize');
const sequelize = require('../db');


const Carrinho = sequelize.define('Carrinho', {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    id_produto: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    quantidade: {
      type: DataTypes.INTEGER,
    },
  });
  
  const Pedido = sequelize.define('Pedido', {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    data_pedido: {
      type: DataTypes.STRING(10),
    },
    valor: {
      type: DataTypes.INTEGER,
    },
    forma_pagamento: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
  });

  module.exports = Carrinho;