const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const ContaBancaria = sequelize.define('ContaBancaria', {
    id_conta: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    id_cadastro: {
      type: DataTypes.INTEGER,
    },
    numero_conta: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    agencia: {
      type: DataTypes.STRING(10),
      allowNull: false,
    },
    banco: {
      type: DataTypes.STRING(50),
    },
    cvv: {
      type: DataTypes.STRING(3),
    },
  });
  
  module.exports = ContaBancaria;