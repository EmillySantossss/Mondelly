const Estilista= require('./Estilista');
const Produto= require('./Produto');
const Favoritos= require('./Favoritos');
const ContaBancaria= require('./ContaBancaria');
const Carrinho= require('./Carrinho');
const Evento= require('./Evento');
const Agendamento= require('./Agendamento');
const Galeria= require('./Galeria');
const Perfil= require('./Perfil');
const Cadastro= require('./Cadastro');

module.exports = () => {
  // 1-1: Cadastro -> Perfil
  Cadastro.hasOne(Perfil, { foreignKey: 'id_imagem' });
  Perfil.belongsTo(Cadastro, { foreignKey: 'id_imagem' });

  // 1-N: Cadastro -> Estilista
  Cadastro.hasMany(Estilista, { foreignKey: 'id_cadastro' });
  Estilista.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Estilista -> Produto
  Estilista.hasMany(Produto, { foreignKey: 'id_estilista' });
  Produto.belongsTo(Estilista, { foreignKey: 'id_estilista' });

  // 1-N: Cadastro -> Favoritos
  Cadastro.hasMany(Favoritos, { foreignKey: 'id_cadastro' });
  Favoritos.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Produto -> Favoritos
  Produto.hasMany(Favoritos, { foreignKey: 'id_produto' });
  Favoritos.belongsTo(Produto, { foreignKey: 'id_produto' });

  // 1-N: Cadastro -> ContaBancaria
  Cadastro.hasMany(ContaBancaria, { foreignKey: 'id_cadastro' });
  ContaBancaria.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Cadastro -> Carrinho
  Cadastro.hasMany(Carrinho, { foreignKey: 'id_cadastro' });
  Carrinho.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Cadastro -> Evento
  Cadastro.hasMany(Evento, { foreignKey: 'id_cadastro' });
  Evento.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Cadastro -> Agendamento
  Cadastro.hasMany(Agendamento, { foreignKey: 'id_cadastro' });
  Agendamento.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });

  // 1-N: Cadastro -> Galeria
  Cadastro.hasMany(Galeria, { foreignKey: 'id_cadastro' });
  Galeria.belongsTo(Cadastro, { foreignKey: 'id_cadastro' });
};
