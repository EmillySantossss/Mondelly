const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Evento = sequelize.define('Evento', {
    id_evento: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    nome: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    descricao: {
      type: DataTypes.TEXT,
    },
    data_hora: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    localizacao: {
      type: DataTypes.STRING,
    },
    tipo_evento: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    vagas: {
      type: DataTypes.INTEGER,
    },
    tema: {
      type: DataTypes.STRING,
    },
  });
  
  module.exports = Evento;