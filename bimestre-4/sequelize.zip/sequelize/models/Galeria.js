const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Galeria = sequelize.define('Galeria', {
  id_imagem: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  id_estilista: {
    type: DataTypes.INTEGER,
  },
  id_usuario: {
    type: DataTypes.INTEGER,
  },
  descricao: {
    type: DataTypes.TEXT,
  },
});

module.exports = Galeria;
