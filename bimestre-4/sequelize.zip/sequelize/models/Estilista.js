const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Estilista = sequelize.define('Estilista', {
  id_estilista: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  id_cadastro: {
    type: DataTypes.INTEGER,
  },
  data_inicio: {
    type: DataTypes.STRING(10),
    allowNull: false,
  },
});

module.exports = Estilista;
