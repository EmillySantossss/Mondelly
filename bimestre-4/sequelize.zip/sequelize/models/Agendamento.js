const { DataTypes } = require('sequelize');
const sequelize= require('../db');

const Agendamento = sequelize.define('Agendamento', {
    id_evento: {
      type: DataTypes.INTEGER,
    },
    id_cadastro: {
      type: DataTypes.INTEGER,
    },
    data_agendamento: {
      type: DataTypes.STRING(10),
      allowNull: false,
    },
    quantidade_assessoria: {
      type: DataTypes.INTEGER,
    },
  });

  module.exports = Agendamento;