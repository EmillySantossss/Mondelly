const sequelize = require('./db');
const Agendamento = require('./models/Agendamento');
const Cadastro = require('./models/Cadastro');
const Carrinho = require('./models/Carrinho');
const ContaBancaria = require('./models/ContaBancaria');
const Estilista = require('./models/Estilista');
const Evento = require('./models/Evento');
const Favoritos = require('./models/Favoritos');
const Galeria = require('./models/Galeria');
const Perfil = require('./models/Perfil');
const Produto = require('./models/Produto');
const Relacionamento = require('./models/Relacionamento');

(async () => {
  try {
    // Configurar relacionamentos
    Relacionamento(); // Chama a função corretamente

    // Sincronizar o banco de dados
    await sequelize.sync({ force: true });
    console.log('Banco de dados sincronizado.');

  } catch (error) {
    console.error('Erro ao sincronizar o banco de dados:', error);
  }
}
)();
